================================================================================
PROYEK AKHIR WEB DESIGN: SISTEM INVENTARIS LAB TKJ
SMKN 2 PEKALONGAN
================================================================================

Identitas Siswa:
- Nama         : Muhamad Zainurroyan
- Kelas        : 12 TKJ 1
- No. Absen    : 19
- Sekolah      : SMKN 2 Pekalongan
- Guru Pengampu: Pak Andi Darmayanto (Guru Web Design)

Fitur Unggulan Proyek (100% Memenuhi Rubrik):
1. CRUD Lengkap Perangkat Laboratorium TKJ (Tambah, Edit, Hapus dengan Modal).
2. Spesifikasi Alamat IP Jaringan (Network IP / DHCP) untuk setiap perangkat.
3. Ekspor Data Fleksibel: Ekspor Excel (CSV) & Ekspor JSON serta Cetak Laporan Resmi.
4. Pencarian instan berdasarkan Nama, IP Address, atau Merek, serta Filter Kategori & Kondisi.
5. Perhitungan statistik otomatis (Unit fisik, rasio Baik/Rusak, kesiapan lab).
6. Penyimpanan persisten di LocalStorage browser & inisialisasi data via fetch().
7. Desain Responsif & Bersih (Mobile & Desktop).

Struktur Berkas Proyek:
├── index.html        (Halaman utama aplikasi - struktur HTML semantik)
├── css/
│   └── style.css     (Desain responsif, clean & monochrome)
├── js/
│   └── script.js     (Logika JavaScript murni, DOM, CRUD, Math, IP, Filter, Ekspor CSV/JSON)
├── data/
│   └── perangkat.json(Database awal perangkat laboratorium TKJ - kondisi awal kosong [])
└── README.txt        (Identitas proyek & panduan)

Petunjuk Penggunaan:
1. Ekstrak seluruh isi file ZIP ke dalam satu folder.
2. Buka "index.html" di browser (Google Chrome, Edge, Firefox).
3. Tambah perangkat baru melalui form "+ Tambah Perangkat", lengkapi nama, kategori, merek, kuantitas, kondisi, alamat IP, dan lokasi.
4. Pada menu "Laporan & Ekspor", klik "Export Excel (CSV)" untuk mengunduh berkas tabel spreadsheet yang siap dibuka di Microsoft Excel.
================================================================================
